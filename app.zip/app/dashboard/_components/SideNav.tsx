"use client";
import { FileClock, Home, Settings, Wallet, WalletCards } from 'lucide-react'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import React, { useEffect } from 'react'
import Link from "next/link";

function SideNav() {
  const  MenuList = [
    {
      name:'Home',
      icon:Home,
      path:'/dashboard'
    },
    {
      name: "Settings",
      icon: Settings,
      path: "/dashboard/Settings",
    },
    // {
    //   name:'History',
    //   icon:FileClock,
    //   path:'/dashboard/history'
    // },
    // {
    //   name:'Billing',
    //   icon:WalletCards,
    //   path:'/dashboard/billing'
    // },
  
]

  const path=usePathname();
  useEffect(()=>{
    console.log(path)
  },[])

  return (
    <div className='h-screen p-5 shadow-sm border bg-white'>
        {/* <div className='flex justify-center text-violet-600 border '>
        <Image src={'/logo.svg'} alt='logo' width={100} height={100}/>
        CODE KI DUNIYA 
        </div> */}
        <div className="flex justify-center text-violet-600 border text-2xl font-extrabold tracking-wide uppercase font-mono">
          CODE KI DUNIYA
        </div>

        <hr className='my-9 border'/>
        <div className='mt-3'>
            {MenuList.map((menu,index)=>(
              <Link key={index} href={menu.path} className="block">
              <div className={`flex gap-2 mb-2 p-3
              hover:bg-violet-600 hover:text-white rounded-lg
              cursor-pointer items-center
              ${path==menu.path&&'bg-violet-600 text-white'}
              `}>
                <menu.icon/>
                <h2>{menu.name}</h2>
              </div>
              </Link>
          ))}
        </div>
    </div>
  )
}

export default SideNav