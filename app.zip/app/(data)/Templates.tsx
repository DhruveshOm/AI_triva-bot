
// export default[
//     {
//         name:'Blog Title',
//         desc:'An AI tool to generate blog title',
//         category:'Blog',
//         icon:'https://cdn-icons-png.flaticon.com/128/1674/1674711.png',
//         aiPrompt:'Give me 10 blog topic idea in buttet wise only niche and outline topic and give me result in Rich text editor format.',
//         slug:'generate-blog -title',
//         form:[
//             {
//                 label:'Enter your blog niche',
//                 field:'input',
//                 name:'niche',
//                 required:true
//             },
//             {
//                 label:'Enter blog outline',
//                 field:'textarea',
//                 name:'outline'
//             }
//         ]
//     },

//     {
//         name: "Essay Title",
//         desc: "An AI tool to generate essay titles",
//         category: "Essay",
//         icon: "https://cdn-icons-png.flaticon.com/128/1674/1674711.png",
//         aiPrompt:
//           "Generate 10 essay titles in bullet points based on the given topic. The titles should be engaging and suitable for academic or general writing.",
//         slug: "generate-essay-title",
//         form: [
//           {
//             label: "Enter your essay topic",
//             field: "input",
//             name: "topic",
//             required: true,
//           }
//         ]
//     },

//       {
//         name: "Blog Content",
//         desc: "An AI tool to generate blog content",
//         category: "Blog",
//         icon: "https://cdn-icons-png.flaticon.com/128/2337/2337906.png",
//         aiPrompt:
//           "Generate a well-structured blog post based on the given title and outline. The content should be engaging and formatted properly for a blog.",
//         slug: "generate-blog-content",
//         form: [
//           {
//             label: "Enter your blog title",
//             field: "input",
//             name: "title",
//             required: true,
//           },
//           {
//             label: "Enter blog outline",
//             field: "textarea",
//             name: "outline",
//           },
//         ],
//       },
//       {
//         name: "Text Improver",
//         desc: "An AI tool to enhance and improve text",
//         category: "Writing",
//         icon: "https://cdn-icons-png.flaticon.com/128/685/685655.png",
//         aiPrompt:
//           "Rewrite the given text to improve clarity, grammar, and engagement while keeping the original meaning intact.",
//         slug: "text-improver",
//         form: [
//           {
//             label: "Enter your text",
//             field: "textarea",
//             name: "text",
//             required: true,
//           },
//         ],
//       },
//       {
//         name: "Code Writer",
//         desc: "An AI tool to generate code snippets",
//         category: "Programming",
//         icon: "https://cdn-icons-png.flaticon.com/128/1828/1828817.png",
//         aiPrompt:
//           "Generate optimized and well-commented code for the given programming task. The output should be in a suitable programming language.",
//         slug: "code-writer",
//         form: [
//           {
//             label: "Describe your coding task",
//             field: "textarea",
//             name: "task",
//             required: true,
//           },
//           {
//             label: "Preferred programming language",
//             field: "input",
//             name: "language",
//           },
//         ],
//       },
// ];




export default [
  {
    name: "AI Code Review Assistant",
    desc: "An AI tool to detect vulnerabilities in code",
    category: "Programming",
    icon: "https://cdn-icons-png.flaticon.com/128/1828/1828817.png",
    aiPrompt:
      "Analyze the given code for potential security vulnerabilities, performance issues, and best practices. Provide recommendations for improvement.",
    slug: "ai-code-review",
    form: [
      {
        label: "Paste your code",
        field: "textarea",
        name: "code",
        required: true,
      },
      {
        label: "Specify programming language",
        field: "input",
        name: "language",
      },
    ],
  },
  {
    name: "AI Research Paper Summarizer",
    desc: "Summarize long research papers into key insights",
    category: "Education",
    icon: "https://cdn-icons-png.flaticon.com/128/1031/1031712.png",
    aiPrompt:
      "Summarize the given research paper into key points, highlighting the main findings and conclusions in an easy-to-understand format.",
    slug: "ai-research-summary",
    form: [
      {
        label: "Paste research paper text",
        field: "textarea",
        name: "paper",
        required: true,
      },
    ],
  },
  {
    name: "AI Career Recommendation System",
    desc: "AI-powered career guidance based on skills",
    category: "Career",
    icon: "https://cdn-icons-png.flaticon.com/128/3135/3135755.png",
    aiPrompt:
      "Based on the given skills and interests, suggest suitable career paths with job market insights and skill development recommendations.",
    slug: "ai-career-recommendation",
    form: [
      {
        label: "List your skills",
        field: "textarea",
        name: "skills",
        required: true,
      },
      {
        label: "Your interests",
        field: "input",
        name: "interests",
      },
    ],
  },
  {
    name: "AI Homework Helper",
    desc: "Explains homework answers step-by-step",
    category: "Education",
    icon: "https://cdn-icons-png.flaticon.com/128/2907/2907025.png",
    aiPrompt:
      "Provide a detailed step-by-step explanation for the given question, making it easy for students to understand.",
    slug: "ai-homework-helper",
    form: [
      {
        label: "Enter your question",
        field: "textarea",
        name: "question",
        required: true,
      },
    ],
  },
  {
    name: "AI College Admission Chatbot",
    desc: "Guidance for college admissions & course selection",
    category: "Education",
    icon: "https://cdn-icons-png.flaticon.com/128/2890/2890345.png",
    aiPrompt:
      "Provide guidance on college admission processes and suggest suitable courses based on the user's preferences.",
    slug: "ai-college-admission",
    form: [
      {
        label: "Enter your academic background",
        field: "textarea",
        name: "background",
        required: true,
      },
      {
        label: "Your interests",
        field: "input",
        name: "interests",
      },
    ],
  },
  {
    name: "AI Book Summarizer",
    desc: "Summarize books for students",
    category: "Education",
    icon: "https://cdn-icons-png.flaticon.com/128/1946/1946488.png",
    aiPrompt:
      "Summarize the given book or chapter into key points, highlighting main ideas and takeaways.",
    slug: "ai-book-summarizer",
    form: [
      {
        label: "Enter book title or chapter",
        field: "input",
        name: "title",
        required: true,
      },
      {
        label: "Paste book text (optional)",
        field: "textarea",
        name: "text",
      },
    ],
  },
  {
    name: "AI Legal Document Summarizer",
    desc: "Summarize legal documents effectively",
    category: "Legal",
    icon: "https://cdn-icons-png.flaticon.com/128/2211/2211187.png",
    aiPrompt:
      "Summarize the given legal document into key points while maintaining accuracy and clarity.",
    slug: "ai-legal-summarizer",
    form: [
      {
        label: "Paste legal document text",
        field: "textarea",
        name: "document",
        required: true,
      },
    ],
  },
  {
    "name": "MCQ Generator",
    "desc": "An AI tool to generate 20 multiple-choice questions (MCQs) based on a given topic",
    "category": "Education",
    "icon": "https://cdn-icons-png.flaticon.com/128/1828/1828817.png",
    "aiPrompt": "Generate 20 multiple-choice questions (MCQs) based on the given topic. Each question should have four answer options labeled (A), (B), (C), and (D). At the end, provide the correct answers for all questions.",
    "slug": "mcq-generator",
    "form": [
      {
        "label": "Enter your topic",
        "field": "input",
        "name": "topic",
        "required": true
      }
    ]
  }
];
